import React from "react";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import Home from "./pages/Home";
import About from "./pages/About";
import Cart from "./pages/Cart";
import "./App.css";
import Nav from "./components/Nav";

const navRouter = createBrowserRouter([
  {
    path: "/",
    element: <Home></Home>,
    children: [
      {
        path: "/about",
        element: <About></About>,
      },
      {
        path: "/cart",
        element: <Cart></Cart>,
      },
    ],
  },
]);

const App = () => {
  return (
    <>
      <RouterProvider router={navRouter}>
        <Nav></Nav>
      </RouterProvider>
    </>
  );
};

export default App;
